#include <iostream>
#include <iomanip>
using namespace std;

// Check if a year is a leap year
bool isLeap(int year) {
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

// Get number of days in a month
int getDaysInMonth(int month, int year) {
    int daysInMonth[] = {31, isLeap(year) ? 29 : 28, 31, 30, 31, 30,
                         31, 31, 30, 31, 30, 31};
    return daysInMonth[month - 1];
}

// Get the day of the week for 1st Jan of the given year (0=Sun, 6=Sat)
int getDayOfWeek(int day, int month, int year) {
    if (month < 3) {
        month += 12;
        year--;
    }
    int k = year % 100;
    int j = year / 100;
    int h = (day + 13*(month + 1)/5 + k + k/4 + j/4 + 5*j) % 7;
    return (h + 6) % 7; // Convert Zeller's result to 0=Sun, 6=Sat
}

int main() {
    int year, month;
    string months[] = {"January", "February", "March", "April", "May", "June",
                       "July", "August", "September", "October", "November", "December"};

    cout << "Enter year: ";
    cin >> year;
    cout << "Enter month (1-12): ";
    cin >> month;

    int days = getDaysInMonth(month, year);
    int startDay = getDayOfWeek(1, month, year);

    // Display calendar header
    cout << "\n   " << months[month - 1] << " " << year << endl;
    cout << "Su Mo Tu We Th Fr Sa\n";

    // Print leading spaces
    for (int i = 0; i < startDay; i++)
        cout << "   ";

    // Print days
    for (int day = 1; day <= days; day++) {
        cout << setw(2) << day << " ";
        if ((startDay + day) % 7 == 0)
            cout << endl;
    }

    cout << endl;
    return 0;
}


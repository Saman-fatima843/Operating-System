#include <iostream>
#include <vector>
using namespace std;

class TicTacToe {
private:
    vector<vector<char>> board;
    char currentPlayer;

public:
    TicTacToe() : board(3, vector<char>(3, ' ')), currentPlayer('X') {}

    void printBoard() {
        cout << "\n";
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                cout << " " << board[i][j] << " ";
                if (j < 2) cout << "|";
            }
            cout << "\n";
            if (i < 2) cout << "---+---+---\n";
        }
    }

    bool isWin() {
        for (int i = 0; i < 3; i++) {
            // Check rows
            if (board[i][0] == currentPlayer && board[i][1] == currentPlayer && board[i][2] == currentPlayer)
                return true;
            // Check columns
            if (board[0][i] == currentPlayer && board[1][i] == currentPlayer && board[2][i] == currentPlayer)
                return true;
        }

        // Check diagonals
        if (board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer)
            return true;
        if (board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer)
            return true;

        return false;
    }

    bool isBoardFull() {
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++)
                if (board[i][j] == ' ')
                    return false;
        return true;
    }

    void makeMove(int row, int col) {
        if (board[row][col] == ' ') {
            board[row][col] = currentPlayer;
            if (isWin()) {
                printBoard();
                cout << "\nPlayer " << currentPlayer << " wins!" << endl;
                exit(0);  // Game over
            }
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X'; // Switch player
        } else {
            cout << "Cell already occupied, try again!" << endl;
        }
    }

    void play() {
        int row, col;
        while (!isBoardFull()) {
            printBoard();
            cout << "\nPlayer " << currentPlayer << ", enter row and column (0-2): ";
            cin >> row >> col;
            if (row >= 0 && row < 3 && col >= 0 && col < 3)
                makeMove(row, col);
            else
                cout << "Invalid input, try again!" << endl;
        }
        printBoard();
        cout << "It's a draw!" << endl;
    }
};

int main() {
    TicTacToe game;
    game.play();
    return 0;
}


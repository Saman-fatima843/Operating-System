#include <iostream>
#include <fstream>  // For file handling
using namespace std;

int main() {
    string filename = "example.txt";  // File name to create
    ofstream file;  // Output file stream

    // Open the file for writing
    file.open(filename);

    // Check if the file was created successfully
    if (file.is_open()) {
        file << "Hello, this is a test file!" << endl;
        file << "I am from FAST CFD campus." << endl;
        file << "File creation and writing successful." << endl;

        cout << "File created and data written successfully!" << endl;

        // Close the file
        file.close();
    } else {
        cout << "Error: Unable to create the file!" << endl;
    }

    return 0;
}


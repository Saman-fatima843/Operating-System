#include <iostream>
#include <fstream>  // For file handling
#include <cstdio>   // For remove() function
using namespace std;

int main() {
    string filename = "example.txt";  // File to be deleted

    // Try to delete the file
    if (remove(filename.c_str()) != 0) {
        cout << "Error: Unable to delete the file!" << endl;
    } else {
        cout << "File '" << filename << "' deleted successfully!" << endl;
    }

    return 0;
}


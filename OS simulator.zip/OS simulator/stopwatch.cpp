#include <iostream>
#include <chrono>
using namespace std;
using namespace std::chrono;

int main() {
    cout << "Stopwatch started... Press Enter to stop." << endl;

    auto start = high_resolution_clock::now();

    // Wait for Enter key
    cin.get();

    auto end = high_resolution_clock::now();
    auto duration = duration_cast<seconds>(end - start);

    cout << "Elapsed time: " << duration.count() << " seconds" << endl;
    return 0;
}


#include <iostream>
#include <ctime>
using namespace std;

int main() {
    time_t now = time(0);               // Current time
    tm *ltm = localtime(&now);          // Convert to local time

    cout << "Current Time and Date:\n";
    cout << "Year: " << 1900 + ltm->tm_year << endl;
    cout << "Month: " << 1 + ltm->tm_mon << endl;
    cout << "Day: " << ltm->tm_mday << endl;
    cout << "Time: "
         << ltm->tm_hour << ":"
         << ltm->tm_min << ":"
         << ltm->tm_sec << endl;

    return 0;
}


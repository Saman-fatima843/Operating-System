#include <iostream>
using namespace std;

int main() {
    string input;
    cout << "Enter a string: ";
    getline(cin, input);

    int length = 0;
    for (char c : input)
        length++;

    cout << "Length of the string: " << length << endl;
    return 0;
}

